# Blueprint Studio — Mobile Device Lifecycle

Interactive service blueprint tool built with React + Vite.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server (opens at http://localhost:3000)
npm run dev

# 3. Build for production
npm run build

# 4. Preview production build locally
npm run preview
```

---

## Project structure

```
blueprint-studio/
├── index.html                 # HTML entry point
├── vite.config.js             # Vite configuration
├── package.json
├── .gitignore
└── src/
    ├── main.jsx               # React root mount
    ├── App.jsx                # App shell (imports ServiceBlueprint)
    └── ServiceBlueprint.jsx   # ← main component (all logic lives here)
```

All blueprint logic — state, PDF export, branching, lane/stage CRUD — is
self-contained in `src/ServiceBlueprint.jsx`. jsPDF is loaded on demand from
the Cloudflare CDN when the user triggers a PDF export (no local dependency).

---

## Current features

- 5 swim lanes × 6 stages (fully editable)
- Per-stage journey branching (add/rename/delete branch paths)
- Inline cell editing with Touchpoint / Fail Point / Moment of Truth markers
- Line of Visibility — toggle position per lane
- Add / rename / delete lanes and stages
- New Stage dialog
- JSON export (full blueprint state)
- A3 landscape PDF export with crop marks, file/registration marks, section
  index tabs, multi-page tiling, and marker legend

---

## Deploying to Azure Static Web Apps

1. Run `npm run build` — output goes to `dist/`
2. In Azure Portal, create a Static Web App and point it at this repo
3. Set the app location to `/` and output location to `dist`
4. Add an AAD identity provider under Settings → Authentication
5. Share via direct link (avoid iFrame embeds in SharePoint — AAD auth
   conflicts with cross-origin iFrame restrictions)

---

## Extending with Claude Code

Suggested prompts to continue development:

```
# Add File System Access API open/save
"Add a File > Open and File > Save As using the File System Access API
(Chrome/Edge). Show a Safari fallback warning. Store last-used file handle
in a ref so Cmd+S saves in place."

# Add localStorage crash recovery
"On every state change, debounce-persist the full blueprint state to
localStorage under key 'blueprint-autosave'. On mount, if autosave exists
and differs from defaults, show a recovery banner offering Restore or Dismiss."

# Add Presentation Mode
"Add a Presentation Mode toggle (keyboard shortcut P) that hides all editing
chrome — toolbar buttons, rename/delete controls, add-lane row, status bar —
while keeping scroll and marker badges visible."

# Add mobile stakeholder view
"Add a simplified read-only mobile view that renders at <768 px: stack lanes
vertically with stage pills as horizontal scroll tabs. Activated via
?mode=review URL param."

# Improve PDF
"In the A3 PDF export, add a cover page with the blueprint title, date,
a legend table, and a stage-count summary. Use a dark navy theme matching
the screen aesthetic."
```

---

## Requirements

- Node.js 18+
- npm 9+
- Chrome or Edge recommended (for File System Access API when added)
