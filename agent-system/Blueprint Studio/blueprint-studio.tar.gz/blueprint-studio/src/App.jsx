import ServiceBlueprint from './ServiceBlueprint.jsx'

export default function App() {
  return <ServiceBlueprint />
}
